# Little Worlds — v0.6: Resizable Ecological Dashboard

A small offline desktop ecosystem built in Python/Tkinter. It is an **educational simulation toy**, not a validated ecology model.

## Launch on Windows

1. Extract the ZIP and keep the `mini_ecosystem` folder intact.
2. Install **Python 3.10 or newer** from python.org.
3. Double-click **Launch Little Worlds.bat**.
4. If Windows cannot find Python, install again with **Add python.exe to PATH**, or launch from a terminal with `py -3 terrarium.py`.

No extra Python packages or internet connection are required to run the app.

## New in v0.6

### Visual redesign and resizable layout
- **Resizable panels** using split panes:
  - left side split between the habitat and the journal
  - main split between the habitat side and the dashboard
  - dashboard split between the top monitoring stack and the lower tabbed tools
- **Collapsible dashboard** button in the header to maximise habitat space.
- **Always-visible history graph** stays in the dashboard while detailed interpretation remains in the tabs.

### Better ecological monitoring
- **Larger journal area** with Main, Critical events, and Help & tips tabs.
- **Persistent notifications panel** for ecological warnings.
- **Clickable alerts** remain available: selecting a notification opens an investigation with explanation, trend summary, suggested actions, and a map-highlighting button.
- **Map overlays** for:
  - Vegetation
  - Moisture
  - Predator pressure
  - Human development

### Creature viewer improvements
- Larger **creature viewer** with a bundled image card for each species.
- More readable information about:
  - diet
  - predators / threats
  - generation and parents
  - health, thirst, and energy
  - inherited traits

## About the creature images

This version bundles **offline species cards** in `/assets` so the viewer works without internet.

The code is prepared to use local PNG wildlife photos instead. If you want to replace the cards with real images later, simply swap these files:

- `assets/kiwi.png`
- `assets/weta.png`
- `assets/rat.png`
- `assets/stoat.png`
- `assets/human.png`

Use the same filenames and the app will display them automatically.

## Core controls

- **Inspect**: click a creature to view detailed information.
- **Map overlay**: switch the habitat view between no overlay, vegetation, moisture, predator pressure, and human development.
- **Interventions tab**: change rainfall, temperature, sunlight, metabolism, introduce organisms, build houses, restore habitat, or run predator control.
- **Development policy**: choose Balanced, Conservation, or Expansion.
- **History graph**: switch between Populations, Habitat, and Settlement views.
- **Insights tab**: in-depth breakdowns of changes, habitat indicators, and major events.
- **Save / Load**: autosaves on exit and periodically while running.

## Compatibility

- Existing v0.5.x saves should still load.
- This build keeps the same general save structure, but backing up `%USERPROFILE%\.little_worlds\autosave.json` before upgrading is recommended.

## Educational caveats

The simulation is intentionally simplified:
- accelerated seasons and life cycles
- abstract predator-prey relationships
- simplified settlement behaviour
- stylised habitat and restoration systems

It should be used as a **learning and experimentation tool**, not as a predictor of real New Zealand ecological outcomes.

## Useful real-world references

- Department of Conservation: https://www.doc.govt.nz/nature/native-animals/birds/birds-a-z/kiwi/facts/
- Department of Conservation: https://www.doc.govt.nz/nature/pests-and-threats/animal-pests-and-threats/stoats/
- Department of Conservation: https://www.doc.govt.nz/predator-control-programme
