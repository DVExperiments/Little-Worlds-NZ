# LITTLE WORLDS — Living Terrarium

A small, autonomous ecosystem in a desktop window. No APIs, no subscription, and no third-party Python packages required.

## Windows setup

1. Install **Python 3.10 or newer** from https://www.python.org/downloads/ if not already installed. Standard Python installs include Tkinter.
2. Unzip this folder somewhere you want to keep it.
3. Double-click **Launch Little Worlds.bat**, or run `python terrarium.py` in a terminal.

## How to play

- **Watch:** Animals graze, forage, hunt, age, reproduce, and die. Plants grow with light, moisture, and nutrients; microbes and fungi break down organic material.
- **Inspect:** Click any tile to see soil moisture, plant coverage, fungi, microbes, nutrients, and nearby animals.
- **Intervene:** Select a life form or soil tool on the right, click the habitat to introduce it, or click **Sprinkle selected across world**.
- **Adjust:** Change temperature, rainfall, sunlight, and metabolic demands while the ecosystem is running.
- **Live feed:** Scroll the activity journal below the habitat for timestamped rain, flooding, births, deaths and ecological milestones. Use **Clear feed** to reset it.
- **Water level:** Sustained rainfall fills the pond and can flood low ground. In dry weather it slowly recedes; extreme settings can be disruptive.
- **Observe:** Time continues while the application is open, with adjustable speed and pause. Each day includes a natural light cycle, and seasons change every 24 simulation days.
- **Preserve:** It autosaves approximately once per minute and when closing normally. You can also use **Save as… / Load…** to keep several worlds.

## Ecology model

Mossbacks (herbivores) eat plants. Ember foxes eat mossbacks and beetles. Dusk beetles feed on detritus. Dead organisms and plant litter contribute detritus, which decomposers process into nutrients for plants. Weather changes soil moisture; rainfall, season, light and temperature influence growth and survival. All creatures have energy, thirst and age, and can reproduce when conditions support them.

This is a **stylized simulation**, not a scientifically calibrated ecological model. Microscopic life is represented by microbial biomass per tile (and fungi by fungal coverage), not individual microscopic organisms. Ecosystems may collapse, particularly after extreme conditions or overpopulation; add life or start a new world to experiment again.

## Data and privacy

The application is offline and writes only local JSON saves. Autosaves live in `%USERPROFILE%\.little_worlds\autosave.json` on Windows. Manual saves can be placed anywhere.

## Build optional standalone `.exe`

If you'd rather not install Python on the target computer, install PyInstaller *on your development machine* (`py -m pip install pyinstaller`), then run:

```
py -m PyInstaller --noconfirm --onefile --windowed --name LittleWorlds terrarium.py
```

The executable is created in `dist\LittleWorlds.exe`. Build the Windows `.exe` on Windows.
