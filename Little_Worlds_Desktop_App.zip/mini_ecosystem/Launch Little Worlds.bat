@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 terrarium.py
) else (
  python terrarium.py
)
if errorlevel 1 (
  echo.
  echo Little Worlds could not start. Install Python from https://www.python.org/downloads/
  echo Make sure Python and Tcl/Tk are included.
  pause
)
