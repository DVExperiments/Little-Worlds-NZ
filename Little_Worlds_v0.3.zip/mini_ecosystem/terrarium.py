"""LITTLE WORLDS — an autonomous ecosystem in a window.
Pure Python 3.10+ / Tkinter. Run: python terrarium.py
"""
from __future__ import annotations
import json, math, os, random, sys, time
from dataclasses import dataclass, asdict
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "LITTLE WORLDS  •  Aotearoa Terrarium v0.3"
W, H, CELL = 58, 32, 15
SAVE_VERSION = 2
HOME = Path.home() / ".little_worlds"
AUTOSAVE = HOME / "autosave.json"
BG = "#0b1319"
PANEL = "#111f25"
PANEL2 = "#17292e"
MUTED = "#87a4aa"
TEXT = "#e5f1e7"
ACCENT = "#a7e5a5"
BLUE = "#79bfcc"
AMBER = "#efca85"


def clamp(v, lo=0, hi=1):
    return max(lo, min(hi, v))


def mix(a, b, weight):
    return a * (1 - weight) + b * weight


def rgb(hexcolor):
    return tuple(int(hexcolor[i:i+2], 16) for i in (1, 3, 5))


def hexrgb(r, g, b):
    return f"#{int(clamp(r, 0, 255)):02x}{int(clamp(g, 0, 255)):02x}{int(clamp(b, 0, 255)):02x}"


SPECIES = {
    "kiwi": dict(name="Brown kiwi", tag="Native bird", diet="Wētā, insects, worms", predators="Stoats (chicks), rats (eggs)", role="Ground-foraging omnivore", color="#cba278", speed=.30, cost=.12, lifespan=65, cap=95, chance=.011),
    "weta": dict(name="Forest wētā", tag="Native invertebrate", diet="Leaves, decaying plants, fungi", predators="Rats, stoats, kiwi", role="Omnivorous detritivore", color="#99846c", speed=.22, cost=.065, lifespan=24, cap=240, chance=.022),
    "rat": dict(name="Ship rat", tag="Introduced predator", diet="Seeds, insects, eggs, wētā", predators="Stoats, human pest control", role="Omnivore and nest predator", color="#b6a0a0", speed=.39, cost=.115, lifespan=38, cap=115, chance=.018),
    "stoat": dict(name="Stoat", tag="Introduced predator", diet="Rats, wētā, young kiwi", predators="Human pest control", role="Agile carnivorous hunter", color="#cc805b", speed=.53, cost=.19, lifespan=50, cap=32, chance=.007),
    "human": dict(name="Human settler", tag="Human", diet="Food grown and collected near villages", predators="None in this simplified model", role="Builds settlements; alters habitats", color="#9cc6e0", speed=.24, cost=.085, lifespan=90, cap=38, chance=.007),
}

@dataclass
class Creature:
    kind: str
    x: float
    y: float
    energy: float = 75
    age: float = 0
    thirst: float = 0
    heading: float = 0
    cooldown: float = 0
    id: int = 0
    name: str = ""
    health: float = 100

    def asdict(self):
        return asdict(self)


class World:
    """Headless simulation; safe to use without launching the Tk GUI."""
    def __init__(self, seed=None):
        self.seed = seed if seed is not None else random.randrange(1, 999_999_999)
        self.rng = random.Random(self.seed)
        self.clock = 0.0
        self.temp_bias = 0.0
        self.rain_bias = 0.0
        self.sun_bias = 0.0
        self.metabolism = 1.0
        self.gravity = 1.0
        self.events = []
        self.water_level = .42
        self.last_rain = False
        self.last_counts = {}
        self.next_id = 1
        self.creatures = []
        self.settlements = []
        self.last_build_day = -1
        self.cells = []
        for y in range(H):
            row = []
            for x in range(W):
                dist = math.hypot((x - 43) / 16, (y - 22) / 11)
                pond = dist < self.water_level
                row.append({
                    "water": bool(pond),
                    "basin": round(dist, 4),
                    "moisture": .72 if pond else self.rng.uniform(.28, .66),
                    "nutrients": self.rng.uniform(.28, .72),
                    "plants": 0.0 if pond else self.rng.uniform(.16, .72),
                    "flower": self.rng.random() < .08 and not pond,
                    "fungus": 0.0 if pond else (self.rng.uniform(.15, .54) if self.rng.random() < .045 else 0.0),
                    "microbes": self.rng.uniform(.25, .65),
                    "detritus": self.rng.uniform(0, .15),
                    "rock": self.rng.random() < .025 and not pond,
                    "building": "",
                })
            self.cells.append(row)
        # The initial population is deliberately stable-ish rather than maximally busy.
        for kind, count in (("kiwi", 18), ("stoat", 3), ("weta", 37), ("rat", 11), ("human", 3)):
            self.spawn(kind, count, announce=False)
        self.last_rain = self.raining
        self.note("A new little world wakes up. Watch it change.")

    def note(self, message):
        self.events.insert(0, (round(self.clock / 24, 1), message))
        self.events = self.events[:300]

    @property
    def day(self):
        return int(self.clock / 24) + 1

    @property
    def hour(self):
        return self.clock % 24

    @property
    def season(self):
        return ["Spring", "Summer", "Autumn", "Winter"][(self.day // 24) % 4]

    @property
    def sunlight(self):
        daylight = max(0, math.sin(math.pi * (self.hour - 6) / 12))
        return clamp(daylight * (1 + self.sun_bias), 0, 1.5)

    @property
    def temperature(self):
        seasonal = {"Spring": 16, "Summer": 25, "Autumn": 13, "Winter": 3}[self.season]
        return seasonal + self.temp_bias + 5 * math.sin((self.hour - 8) / 24 * math.tau)

    @property
    def raining(self):
        # Sustained fronts plus small daily variation, instead of a new coin flip every tick.
        front = math.sin(self.clock / 31 + self.seed) + .45 * math.sin(self.clock / 13)
        return front + self.rain_bias * 1.8 > .58

    def get(self, x, y):
        return self.cells[int(clamp(y, 0, H-1))][int(clamp(x, 0, W-1))]

    def spawn(self, kind, count=1, announce=True, x=None, y=None):
        if kind not in SPECIES: raise ValueError(f"Unknown species: {kind}")
        added = 0
        for _ in range(count):
            px = (x + self.rng.uniform(-1, 1)) if x is not None else self.rng.randrange(W)
            py = (y + self.rng.uniform(-1, 1)) if y is not None else self.rng.randrange(H)
            px, py = clamp(px, 0, W-.001), clamp(py, 0, H-.001)
            if self.get(px, py)["water"]:
                for _ in range(40):
                    px, py = self.rng.randrange(W), self.rng.randrange(H)
                    if not self.get(px, py)["water"]:
                        break
            if self.get(px, py)["water"]:
                continue
            self.creatures.append(Creature(kind, px, py, self.rng.uniform(62, 85),
                                           self.rng.uniform(0, 15), 0, self.rng.random()*math.tau,
                                           0, self.next_id, f"{SPECIES[kind]['name']} #{self.next_id}"))
            self.next_id += 1
            added += 1
        if announce and added:
            self.note(f"Introduced {added} {SPECIES[kind]['name']}(s).")
        return added

    def scatter(self, kind, count=25, x=None, y=None):
        for _ in range(count):
            cx = int(clamp((x if x is not None else self.rng.randrange(W)) + self.rng.gauss(0, 2 if x is not None else 0), 0, W-1))
            cy = int(clamp((y if y is not None else self.rng.randrange(H)) + self.rng.gauss(0, 2 if y is not None else 0), 0, H-1))
            c = self.get(cx, cy)
            if c["water"]:
                continue
            if kind == "plants":
                c["plants"] = max(c["plants"], self.rng.uniform(.65, 1))
                c["flower"] = self.rng.random() < .24
            elif kind == "fungus":
                c["fungus"] = max(c["fungus"], self.rng.uniform(.4, .95))
                c["detritus"] += .12
            elif kind == "microbes":
                c["microbes"] = max(c["microbes"], self.rng.uniform(.7, 1))
            elif kind == "nutrients":
                c["nutrients"] = clamp(c["nutrients"] + .4)
        self.note({"plants":"New seeds take root.", "fungus":"Spores drift into the soil.",
                   "microbes":"A microbial culture is introduced.", "nutrients":"Minerals enrich the soil."}[kind])

    def ecology_metrics(self):
        land = [c for row in self.cells for c in row if not c["water"]]
        counts = {name: sum(c.kind == name for c in self.creatures) for name in SPECIES}
        means = {key: sum(c[key] for c in land) / max(1, len(land)) for key in ("plants", "fungus", "microbes", "moisture", "nutrients")}
        return counts, means

    def tick(self, dt=.32):
        """dt is an in-world hour increment; approximate multi-layer ecosystem dynamics."""
        r = self.rng
        self.clock += dt
        rain = self.raining
        if rain != self.last_rain:
            self.note("Rain begins to fall across the habitat." if rain else "The rain clears and the landscape begins to dry.")
            self.last_rain = rain
        old_level = self.water_level
        # Precipitation fills the basin and dry weather/heat drains it.
        # Water is updated gradually so rainfall has visible, reversible effects.
        evaporation = .00014 + max(0, self.temperature - 19) * .000008
        self.water_level = clamp(self.water_level + dt * ((.0011 + max(0, self.rain_bias) * .0015) if rain else -evaporation), .28, .87)
        if int(old_level * 20) != int(self.water_level * 20):
            self.note("The pond spreads into the lowlands." if self.water_level > old_level else "The pond recedes, uncovering damp soil.")
        flooded = 0
        for row in self.cells:
            for c in row:
                wet = c['basin'] < self.water_level
                if wet and not c['water']:
                    flooded += 1
                    c['plants'] *= .45
                    c['fungus'] *= .65
                if not wet and c['water']:
                    c['moisture'] = .9
                    c['plants'] = max(.06, c['plants'])
                c['water'] = wet
        sunlight = self.sunlight
        temp = self.temperature
        hot = clamp((temp - 15) / 24, 0, 1)
        cold = clamp((7 - temp) / 14, 0, 1)
        # Erosion, evaporation, nutrient uptake, respiration and decomposition.
        for y, row in enumerate(self.cells):
            for x, c in enumerate(row):
                if c["water"]:
                    c["moisture"] = 1.0
                    continue
                shade = .35 + .65 * c["plants"]
                c["moisture"] = clamp(c["moisture"] + (dt * (.019 + .021*self.rain_bias) if rain else 0)
                                      - dt * (.001 + .007*sunlight*(1-shade*.5)*(1+hot)))
                if r.random() < .035 * dt and c["moisture"] > .18:
                    nx = int(clamp(x + r.choice((-1,0,1)),0,W-1))
                    ny = int(clamp(y + r.choice((-1,0,1)),0,H-1))
                    other = self.cells[ny][nx]
                    if not other["water"]:
                        transfer = (c["moisture"] - other["moisture"]) * .07
                        c["moisture"] = clamp(c["moisture"] - transfer)
                        other["moisture"] = clamp(other["moisture"] + transfer)
                water_factor = clamp((c["moisture"] - .07) / .45)
                temperature_factor = clamp(1 - abs(temp - 22) / 33, .03, 1)
                growth = dt*.0105*sunlight*water_factor*temperature_factor*(.3+c["nutrients"])*c["plants"]*(1-c["plants"])
                if c["plants"] < .03 and r.random() < dt*.002*(.25+c["moisture"]):
                    c["plants"] = .055
                death = dt*(.00048 + cold*.0045 + (1-water_factor)*.007)*c["plants"]
                c["plants"] = clamp(c["plants"] + growth - death)
                c["detritus"] = clamp(c["detritus"] + death*.7, 0, 2.0)
                c["nutrients"] = clamp(c["nutrients"] - max(0, growth)*.12)
                decomposability = clamp(c["moisture"]*1.65) * clamp((temp+2)/26)
                consumed = min(c["detritus"], dt*(.0015+.011*c["microbes"]+.006*c["fungus"])*decomposability)
                c["detritus"] = clamp(c["detritus"] - consumed, 0, 2)
                c["nutrients"] = clamp(c["nutrients"] + consumed*.82)
                c["microbes"] = clamp(c["microbes"] + dt*(.008*c["detritus"]*decomposability*(1-c["microbes"])
                                         - .002*(1-decomposability)*c["microbes"] - .0009*c["microbes"]), 0, 1)
                c["fungus"] = clamp(c["fungus"] + dt*(.009*c["detritus"]*decomposability*(1-c["fungus"])
                                      - (.0015 + cold*.003 + (1-decomposability)*.004)*c["fungus"]), 0, 1)
                if c["flower"] and (c["plants"] < .32 or r.random() < dt*.0018):
                    c["flower"] = False
                elif not c["flower"] and c["plants"] > .68 and temp > 10 and r.random() < dt*.004:
                    c["flower"] = True
        before = {kind: sum(a.kind == kind for a in self.creatures) for kind in SPECIES}
        babies, deaths = [], set()
        buckets = {}
        for a in self.creatures:
            buckets.setdefault((int(a.x)//4,int(a.y)//4), []).append(a)
        def near(a, radius=4):
            bx, by = int(a.x)//4, int(a.y)//4
            for gy in range(by-1, by+2):
                for gx in range(bx-1, bx+2):
                    for b in buckets.get((gx,gy), ()):
                        if b is not a and b.id not in deaths and abs(b.x-a.x)<radius and abs(b.y-a.y)<radius:
                            yield b
        for a in self.creatures:
            if a.id in deaths: continue
            sp = SPECIES.get(a.kind)
            if sp is None: continue
            a.age += dt / 24
            a.cooldown = max(0, a.cooldown - dt)
            cell = self.get(a.x, a.y)
            shore = any(self.get(a.x+dx,a.y+dy)['water'] for dx,dy in ((2,0),(-2,0),(0,2),(0,-2)))
            a.thirst = clamp(a.thirst + dt*.004*self.metabolism - (dt*.04 if rain or shore else 0))
            if cell['water'] or (cell['building'] and a.kind != 'human'):
                dry = [(a.x+dx,a.y+dy) for dx,dy in ((2,0),(-2,0),(0,2),(0,-2),(-3,0),(3,0),(0,-3),(0,3))
                       if 0<=a.x+dx<W and 0<=a.y+dy<H and not self.get(a.x+dx,a.y+dy)['water'] and not self.get(a.x+dx,a.y+dy)['building']]
                if dry:
                    a.x,a.y = min(dry,key=lambda q:(q[0]-a.x)**2+(q[1]-a.y)**2)
                    cell=self.get(a.x,a.y)
            a.energy -= dt*sp['cost']*self.metabolism*(1+.40*cold+hot*.22)
            stress=max(0,32-a.energy)/40 + max(0,a.thirst-.65)*1.5
            a.health=clamp(a.health+dt*(.045-.30*stress),0,100)
            threat, target = None, None
            neighbours = list(near(a,4))
            if a.kind == 'kiwi':
                hunters = [b for b in neighbours if b.kind=='stoat' and a.age < 7]
                if hunters: threat = min(hunters,key=lambda b:(b.x-a.x)**2+(b.y-a.y)**2)
                prey = [b for b in neighbours if b.kind=='weta' and abs(b.x-a.x)<1.2 and abs(b.y-a.y)<1.2]
                if prey and r.random()<dt*.14:
                    victim=r.choice(prey); deaths.add(victim.id); a.energy=min(100,a.energy+17)
                else:
                    meal=min(cell['detritus']+.07*cell['plants'],dt*.014)
                    cell['detritus']=max(0,cell['detritus']-meal*.5)
                    a.energy=min(100,a.energy+meal*135)
            elif a.kind == 'weta':
                hunters=[b for b in neighbours if b.kind in ('rat','stoat','kiwi')]
                if hunters: threat=min(hunters,key=lambda b:(b.x-a.x)**2+(b.y-a.y)**2)
                meal=min(cell['detritus']+cell['fungus']*.2+cell['plants']*.1,dt*.023)
                cell['detritus']=max(0,cell['detritus']-meal*.5)
                a.energy=min(100,a.energy+meal*245)
                cell['nutrients']=clamp(cell['nutrients']+meal*.16)
            elif a.kind == 'rat':
                hunters=[b for b in neighbours if b.kind=='stoat']
                if hunters: threat=min(hunters,key=lambda b:(b.x-a.x)**2+(b.y-a.y)**2)
                prey=[b for b in neighbours if b.kind=='weta' and abs(b.x-a.x)<1.1 and abs(b.y-a.y)<1.1]
                if prey and r.random()<dt*.24:
                    deaths.add(r.choice(prey).id);a.energy=min(100,a.energy+24)
                else:
                    meal=min(cell['plants'],dt*.015)
                    cell['plants']-=meal
                    a.energy=min(100,a.energy+meal*190)
                # Introduced rats sometimes predate on kiwi nesting attempts.
                if r.random()<dt*.003:
                    nests=[b for b in neighbours if b.kind=='kiwi' and b.age<3]
                    if nests:
                        deaths.add(r.choice(nests).id)
                        a.energy=min(100,a.energy+27)
                        if r.random()<.3:self.note('A ship rat raided a kiwi nest.')
            elif a.kind == 'stoat':
                prey=[b for b in neighbours if b.kind in ('rat','weta') or (b.kind=='kiwi' and b.age<7)]
                if prey:
                    target=min(prey,key=lambda b:(b.x-a.x)**2+(b.y-a.y)**2)
                    if (target.x-a.x)**2+(target.y-a.y)**2 < 1.2 and r.random()<dt*.34:
                        deaths.add(target.id)
                        a.energy=min(100,a.energy+(36 if target.kind=='rat' else 18))
                        if target.kind=='kiwi': self.note('A stoat killed a young kiwi.')
                        target=None
            elif a.kind == 'human':
                a.energy=min(100,a.energy+dt*.26)
                a.thirst=max(0,a.thirst-dt*.02)
            if threat:
                a.heading=math.atan2(a.y-threat.y,a.x-threat.x)+r.uniform(-.3,.3)
            elif target:
                a.heading=math.atan2(target.y-a.y,target.x-a.x)+r.uniform(-.13,.13)
            elif r.random()<dt*.19:
                a.heading+=r.uniform(-1.1,1.1)
            if a.kind=='kiwi' and not threat:
                candidates=[(self.get(a.x+dx,a.y+dy)['detritus'],dx,dy) for dx,dy in ((2,0),(-2,0),(0,2),(0,-2))]
                best=max(candidates)
                if best[0]>cell['detritus']+.1 and r.random()<dt*.28:a.heading=math.atan2(best[2],best[1])
            speed=sp['speed']*(1.75 if threat else 1)
            nx=clamp(a.x+math.cos(a.heading)*speed*dt,.05,W-.05)
            ny=clamp(a.y+math.sin(a.heading)*speed*dt,.05,H-.05)
            if not self.get(nx,ny)['water'] and (not self.get(nx,ny)['building'] or a.kind=='human'):
                a.x,a.y=nx,ny
            else:a.heading+=math.pi*.65
            if a.energy<=0 or a.health<=0 or a.age>sp['lifespan'] or a.thirst>.93:
                deaths.add(a.id)
                cell['detritus']=clamp(cell['detritus']+(.45 if a.kind=='kiwi' else .24),0,2)
                continue
            if a.energy>71 and a.age>3 and a.cooldown==0 and before[a.kind]+sum(b.kind==a.kind for b in babies)<sp['cap']:
                mate=any(b.kind==a.kind and b.age>3 and b.energy>58 for b in neighbours)
                if mate and r.random()<sp['chance']*dt:
                    new_id=self.next_id;self.next_id+=1
                    babies.append(Creature(a.kind,clamp(a.x+r.uniform(-.65,.65),0,W-.01),
                                            clamp(a.y+r.uniform(-.65,.65),0,H-.01),
                                            45,0,0,r.random()*math.tau,16,new_id,f"{sp['name']} #{new_id}"))
                    a.energy-=17;a.cooldown=26
        # Settlement expansion: every few days people can establish structures near each other.
        if self.day % 4 == 0 and self.day != self.last_build_day and before['human']:
            self.last_build_day=self.day
            if len(self.settlements)<16:
                people=[a for a in self.creatures if a.kind=='human' and a.id not in deaths]
                if people:
                    builder=r.choice(people)
                    self.build_home(builder.x,builder.y,auto=True)
        # Human conservation periodically controls introduced predators near villages.
        if self.settlements and self.day % 9==0 and r.random()<dt*.03:
            buildings=self.settlements
            pests=[a for a in self.creatures if a.kind in ('stoat','rat') and any(abs(a.x-b['x'])<8 and abs(a.y-b['y'])<8 for b in buildings)]
            if pests:
                victim=r.choice(pests);deaths.add(victim.id)
                self.note(f'Settlement predator control removed a {SPECIES[victim.kind]["name"].lower()}.')
        if babies and (len(babies)>=2 or r.random()<.16):
            batch={k:sum(b.kind==k for b in babies) for k in SPECIES}
            self.note('New life: '+', '.join(f'{v} {SPECIES[k]["name"].lower()}' for k,v in batch.items() if v)+' born.')
        if len(deaths)>=3:self.note(f'{len(deaths)} creatures died; nutrients return to the soil.')
        self.creatures=[a for a in self.creatures if a.id not in deaths]+babies
        for kind in SPECIES:
            after=sum(a.kind==kind for a in self.creatures)
            if before[kind] and not after:self.note(f'{SPECIES[kind]["name"]} disappeared from the habitat.')
        if int((self.clock-dt)/24)!=int(self.clock/24) and self.day%7==0:
            counts,_=self.ecology_metrics()
            self.note(f'Day {self.day}: '+', '.join(f'{counts[k]} {SPECIES[k]["name"]}' for k in SPECIES))

    def build_home(self,x,y,auto=False):
        x,y=int(clamp(x,1,W-2)),int(clamp(y,1,H-2))
        locations=sorted(((xx,yy) for yy in range(max(1,y-3),min(H-1,y+4))
                          for xx in range(max(1,x-3),min(W-1,x+4))),
                         key=lambda xy:(xy[0]-x)**2+(xy[1]-y)**2)
        for xx,yy in locations:
            c=self.get(xx,yy)
            if c['water'] or c['building'] or c['rock']:continue
            c['building']='village' if len(self.settlements)%4==3 else 'house'
            c['plants']*=.16;c['fungus']*=.25;c['detritus']+=.08
            self.settlements.append(dict(x=xx,y=yy,kind=c['building']))
            self.note(f"Humans built a {c['building']} at ({xx}, {yy}); vegetation was cleared.")
            return True
        if not auto:self.note('No suitable dry tile was available for building.')
        return False

    def to_dict(self):
        return dict(version=SAVE_VERSION, seed=self.seed, clock=self.clock, temp_bias=self.temp_bias,
                    rain_bias=self.rain_bias, sun_bias=self.sun_bias, metabolism=self.metabolism,
                    gravity=self.gravity, next_id=self.next_id, water_level=self.water_level, cells=self.cells,
                    creatures=[a.asdict() for a in self.creatures], events=self.events,
                    settlements=self.settlements, last_build_day=self.last_build_day, rng_state=None)

    @classmethod
    def from_dict(cls,data):
        if data.get('version') not in (1, SAVE_VERSION):
            raise ValueError('Unsupported terrarium save version')
        w=cls(seed=int(data['seed']))
        if len(data['cells'])!=H or any(len(row)!=W for row in data['cells']):
            raise ValueError('Save dimensions do not match this version')
        w.cells=data['cells']
        w.water_level=float(data.get('water_level', .68))
        for y,row in enumerate(w.cells):
            for x,c in enumerate(row):
                if 'basin' not in c:
                    c['basin'] = round(math.hypot((x - 43) / 16, (y - 22) / 11),4)
        w.last_rain=w.raining
        migration={'grazer':'kiwi','fox':'stoat','beetle':'weta'}
        w.creatures=[]
        for raw in data['creatures']:
            c=dict(raw);c['kind']=migration.get(c['kind'],c['kind'])
            c.setdefault('name',f"{SPECIES[c['kind']]['name']} #{c['id']}")
            w.creatures.append(Creature(**c))
        w.settlements=data.get('settlements',[])
        w.last_build_day=data.get('last_build_day',-1)
        for row in w.cells:
            for c in row:c.setdefault('building','')
        for key in ('clock','temp_bias','rain_bias','sun_bias','metabolism','gravity','next_id'):
            setattr(w,key,data[key])
        w.events=[tuple(v) for v in data.get('events', [])]
        return w


class TerrariumApp:
    def __init__(self, root):
        self.root=root
        root.title(APP_TITLE)
        root.configure(bg=BG)
        root.geometry('1280x850')
        root.minsize(1160,730)
        self.world=self.load_autosave() or World()
        self.speed=tk.IntVar(value=2)
        self.brush=tk.StringVar(value='inspect')
        self.inspect_pos=None
        self.selected_id=None
        self.running=True
        self.tick_number=0
        self.last_time=time.monotonic()
        self.accumulator=0
        self.last_autosave=time.monotonic()
        self.stars=[(random.randrange(W*CELL),random.randrange(H*CELL//2),random.choice((1,1,2))) for _ in range(47)]
        self.setup_ui()
        self.refresh_controls()
        self.draw()
        root.protocol('WM_DELETE_WINDOW',self.close)
        self.loop()

    def load_autosave(self):
        try:
            if AUTOSAVE.exists():
                with AUTOSAVE.open(encoding='utf8') as f:
                    return World.from_dict(json.load(f))
        except (ValueError, OSError, KeyError, TypeError):
            pass
        return None

    def label(self, parent, text, size=10, fg=TEXT, bold=False, **kw):
        return tk.Label(parent,text=text,bg=kw.pop('bg',PANEL),fg=fg,
                        font=('Segoe UI',size,'bold' if bold else 'normal'),anchor='w',**kw)

    def make_button(self,parent,text,cmd,accent=False,width=None):
        b=tk.Button(parent,text=text,command=cmd,bg=('#36584d' if accent else PANEL2),
                    fg=('#eaffd8' if accent else TEXT),activebackground='#416b5b',
                    activeforeground='white',relief='flat',bd=0,cursor='hand2',
                    font=('Segoe UI',10,'bold' if accent else 'normal'),
                    padx=11,pady=8,width=width)
        return b

    def setup_ui(self):
        outer=tk.Frame(self.root,bg=BG)
        outer.pack(fill='both',expand=True,padx=22,pady=16)
        header=tk.Frame(outer,bg=BG)
        header.pack(fill='x',pady=(0,15))
        self.label(header,'✦  LITTLE WORLDS',22,ACCENT,True,bg=BG).pack(side='left')
        self.label(header,'Aotearoa · native wildlife, introduced predators and people',10,MUTED,bg=BG).pack(side='left',padx=18,pady=(9,0))
        self.status=tk.StringVar(value='')
        self.label(header,'',10,BLUE,bg=BG,textvariable=self.status).pack(side='right',pady=(9,0))
        content=tk.Frame(outer,bg=BG)
        content.pack(fill='both',expand=True)
        left=tk.Frame(content,bg=BG)
        left.pack(side='left',fill='both',expand=True)
        right=tk.Frame(content,bg=PANEL,width=315)
        right.pack(side='right',fill='y',padx=(15,0))
        right.pack_propagate(False)
        frame=tk.Frame(left,bg='#243d40',padx=3,pady=3)
        frame.pack(anchor='nw')
        self.canvas=tk.Canvas(frame,width=W*CELL,height=H*CELL,bg='#14252b',bd=0,highlightthickness=0,cursor='crosshair')
        self.canvas.pack()
        self.canvas.bind('<Button-1>',self.click_world)
        self.canvas.bind('<B1-Motion>',self.click_world)
        info=tk.Frame(left,bg=BG)
        info.pack(fill='x',pady=(15,10))
        self.day_label=self.label(info,'',17,TEXT,True,bg=BG)
        self.day_label.pack(side='left')
        self.weather_label=self.label(info,'',11,MUTED,bg=BG)
        self.weather_label.pack(side='right')
        cards=tk.Frame(left,bg=BG)
        cards.pack(fill='x',pady=(0,10))
        self.stat_labels={}
        for name in ('KIWI','WĒTĀ','RATS','STOATS','HUMANS'):
            card=tk.Frame(cards,bg=PANEL,padx=11,pady=10)
            card.pack(side='left',fill='x',expand=True,padx=(0,8))
            self.label(card,name,8,MUTED,True).pack(anchor='w')
            val=self.label(card,'—',19,ACCENT if name=='KIWI' else TEXT,True)
            val.pack(anchor='w',pady=(2,0))
            self.stat_labels[name]=val
        bottom=tk.Frame(left,bg=PANEL,padx=14,pady=10)
        bottom.pack(fill='both',expand=True)
        head=tk.Frame(bottom,bg=PANEL)
        head.pack(fill='x',pady=(0,7))
        self.label(head,'LIVE FEED  /  ECOSYSTEM EVENTS',10,ACCENT,True).pack(side='left')
        self.make_button(head,'Clear feed',self.clear_feed).pack(side='right')
        feed_frame=tk.Frame(bottom,bg=PANEL)
        feed_frame.pack(fill='both',expand=True)
        bar=tk.Scrollbar(feed_frame,orient='vertical')
        bar.pack(side='right',fill='y')
        self.log=tk.Text(feed_frame,bg=PANEL,fg='#a7c5bc',relief='flat',bd=0,highlightthickness=0,
                         height=8,font=('Consolas',10),wrap='word',state='disabled',yscrollcommand=bar.set)
        self.log.pack(side='left',fill='both',expand=True)
        bar.config(command=self.log.yview)
        self.last_feed_snapshot=None
        # Controls panel
        # The creature viewer always stays above the scrollable settings.
        viewer=tk.Frame(right,bg='#20353a',padx=13,pady=10)
        viewer.pack(fill='x')
        self.label(viewer,'CREATURE VIEWER  /  CLICK AN ANIMAL',9,ACCENT,True,bg='#20353a').pack(anchor='w')
        self.portrait=tk.Canvas(viewer,width=275,height=100,bg='#27433e',highlightthickness=0)
        self.portrait.pack(pady=(7,5))
        self.creature_info=tk.StringVar(value='Select a creature in the habitat to see its portrait, diet, predators and current condition.')
        self.label(viewer,'',9,TEXT,bg='#20353a',textvariable=self.creature_info,
                   justify='left',wraplength=275).pack(anchor='w')
        area=tk.Frame(right,bg=PANEL)
        area.pack(fill='both',expand=True)
        scroll_canvas=tk.Canvas(area,bg=PANEL,highlightthickness=0,width=300)
        scroller=tk.Scrollbar(area,orient='vertical',command=scroll_canvas.yview)
        scroll_canvas.configure(yscrollcommand=scroller.set)
        scroller.pack(side='right',fill='y')
        scroll_canvas.pack(side='left',fill='both',expand=True)
        body=tk.Frame(scroll_canvas,bg=PANEL,padx=13,pady=12)
        win=scroll_canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda event:scroll_canvas.configure(scrollregion=scroll_canvas.bbox('all')))
        scroll_canvas.bind('<Configure>',lambda event:scroll_canvas.itemconfigure(win,width=event.width))
        def scroll(event):
            scroll_canvas.yview_scroll(int(-event.delta/120),'units')
        scroll_canvas.bind('<MouseWheel>',scroll)
        body.bind('<MouseWheel>',scroll)
        self.label(body,'WORLD CONTROLS',13,ACCENT,True).pack(anchor='w')
        self.label(body,'Nudge nature. Or just watch.',9,MUTED).pack(anchor='w',pady=(2,13))
        speedrow=tk.Frame(body,bg=PANEL)
        speedrow.pack(fill='x')
        self.make_button(speedrow,'Ⅱ  Pause',self.toggle_pause).pack(side='left',fill='x',expand=True,padx=(0,4))
        self.make_button(speedrow,'New world',self.new_world).pack(side='left',fill='x',expand=True)
        self.label(body,'TIME FLOW',9,MUTED,True).pack(anchor='w',pady=(13,5))
        speedbuttons=tk.Frame(body,bg=PANEL)
        speedbuttons.pack(fill='x')
        for val,label in ((1,'1×'),(2,'2×'),(4,'4×'),(8,'8×')):
            b=self.make_button(speedbuttons,label,lambda s=val:self.speed.set(s))
            b.pack(side='left',fill='x',expand=True,padx=(0,4))
        self.label(body,'ENVIRONMENT',9,MUTED,True).pack(anchor='w',pady=(18,7))
        self.sliders={}
        for name,low,high,initial,cmd in [
            ('Temperature',-15,15,0,lambda v:setattr(self.world,'temp_bias',float(v))),
            ('Rainfall',-1,1,0,lambda v:setattr(self.world,'rain_bias',float(v))),
            ('Sunlight',-.7,.5,0,lambda v:setattr(self.world,'sun_bias',float(v))),
            ('Metabolism',.5,2.5,1,lambda v:setattr(self.world,'metabolism',float(v))),
        ]:
            rw=tk.Frame(body,bg=PANEL)
            rw.pack(fill='x')
            self.label(rw,name,9,TEXT).pack(side='left')
            amount=self.label(rw,str(initial),9,BLUE)
            amount.pack(side='right')
            def onslide(value,act=cmd,out=amount):
                act(value)
                out.config(text=f'{float(value):+.1f}' if abs(float(value)) < 1 else f'{float(value):.1f}')
            s=tk.Scale(body,from_=low,to=high,resolution=.1,orient='horizontal',showvalue=False,
                       bg=PANEL,fg=TEXT,troughcolor='#294248',highlightthickness=0,bd=0,
                       activebackground=ACCENT,command=onslide,length=236)
            s.set(initial)
            s.pack(fill='x',pady=(0,4))
            self.sliders[name]=s
        self.label(body,'INTRODUCE LIFE / TOOLS',9,MUTED,True).pack(anchor='w',pady=(12,7))
        self.brush_choices=[('Inspect','inspect'),('Seeds','plants'),('Fungi','fungus'),
                            ('Microbes','microbes'),('Minerals','nutrients'),
                            ('Kiwi','kiwi'),('Wētā','weta'),('Rats','rat'),('Stoats','stoat'),
                            ('Humans','human'),('Build house','build'),('Predator control','control')]
        tools=tk.Frame(body,bg=PANEL)
        tools.pack(fill='x')
        for i,(label,val) in enumerate(self.brush_choices):
            b=self.make_button(tools,label,lambda t=val:self.set_brush(t))
            b.grid(row=i//2,column=i%2,sticky='ew',padx=2,pady=2)
            tools.grid_columnconfigure(i%2,weight=1)
        self.brush_label=self.label(body,'Selected: Inspect · click a tile',9,AMBER)
        self.brush_label.pack(anchor='w',pady=(7,8))
        self.make_button(body,'Sprinkle selected across world',self.scatter_selected,accent=True).pack(fill='x')
        self.label(body,'SAVE YOUR WORLD',9,MUTED,True).pack(anchor='w',pady=(17,7))
        save_row=tk.Frame(body,bg=PANEL)
        save_row.pack(fill='x')
        self.make_button(save_row,'Save as…',self.save_as).pack(side='left',fill='x',expand=True,padx=(0,5))
        self.make_button(save_row,'Load…',self.load_file).pack(side='left',fill='x',expand=True)
        self.label(body,'Autosaves every minute and on exit.',8,MUTED).pack(anchor='w',pady=(9,0))
        # Below right with inspect info separate
        self.inspector=tk.StringVar(value='Click the habitat to inspect a tile.')
        inspect=tk.Frame(right,bg='#20353a',padx=14,pady=12)
        inspect.pack(side='bottom',fill='x')
        self.label(inspect,'MAGNIFYING GLASS',9,ACCENT,True,bg='#20353a').pack(anchor='w')
        self.label(inspect,'',9,TEXT,bg='#20353a',textvariable=self.inspector,justify='left',wraplength=252).pack(anchor='w',pady=(7,0))

    def clear_feed(self):
        self.world.events.clear()
        self.last_feed_snapshot=None
        self.update_ui()

    def refresh_controls(self):
        for name,key in [('Temperature','temp_bias'),('Rainfall','rain_bias'),('Sunlight','sun_bias'),('Metabolism','metabolism')]:
            self.sliders[name].set(getattr(self.world,key))

    def set_brush(self,value):
        self.brush.set(value)
        text=dict(self.brush_choices).get(value,value)
        pretty=next((k for k,v in self.brush_choices if v==value),value)
        self.brush_label.config(text=f'Selected: {pretty} · click a tile')

    def click_world(self,event):
        x=int(clamp(event.x//CELL,0,W-1))
        y=int(clamp(event.y//CELL,0,H-1))
        brush=self.brush.get()
        self.inspect_pos=(x,y)
        if brush=='inspect':
            candidates=[a for a in self.world.creatures if (a.x-x)**2+(a.y-y)**2<3.5]
            self.selected_id=min(candidates,key=lambda a:(a.x-x)**2+(a.y-y)**2).id if candidates else None
        elif brush in SPECIES:
            self.world.spawn(brush,2 if brush!='weta' else 5,x=x,y=y)
        elif brush=='build':
            self.world.build_home(x,y)
        elif brush=='control':
            pests=[a for a in self.world.creatures if a.kind in ('rat','stoat') and abs(a.x-x)<5 and abs(a.y-y)<5]
            ids={a.id for a in pests}
            self.world.creatures=[a for a in self.world.creatures if a.id not in ids]
            self.world.note(f'Predator-control operation removed {len(ids)} introduced predators.')
        else:
            self.world.scatter(brush,10,x=x,y=y)
        self.update_creature_viewer()
        self.update_inspector()

    def update_inspector(self):
        if self.inspect_pos is None:return
        x,y=self.inspect_pos
        c=self.world.get(x,y)
        nearby=[a for a in self.world.creatures if abs(a.x-x)<1.5 and abs(a.y-y)<1.5]
        if c['water']:
            self.inspector.set(f'({x}, {y}) · Freshwater\nPond level {self.world.water_level*100:.0f}% · aquatic habitat')
        else:
            crit=', '.join(SPECIES[a.kind]['name'] for a in nearby[:3]) or 'none visible'
            self.inspector.set(f'({x}, {y}) · Living soil\nPlants {c["plants"]*100:.0f}%  ·  fungi {c["fungus"]*100:.0f}%\nMicrobes {c["microbes"]*100:.0f}%  ·  moisture {c["moisture"]*100:.0f}%\nNutrients {c["nutrients"]*100:.0f}%  ·  animals: {crit}')

    def update_creature_viewer(self):
        cv=self.portrait
        cv.delete('all')
        a=next((a for a in self.world.creatures if a.id==self.selected_id),None)
        if not a:
            self.creature_info.set('Click a creature in Inspect mode.\n\nDiscover its species, preferred foods, predators, age, energy and thirst.')
            cv.create_text(138,50,text='?',font=('Segoe UI',43,'bold'),fill='#7eaaa0')
            return
        sp=SPECIES[a.kind]
        cv.create_oval(95,15,180,93,fill='#41604f',outline='#53745e')
        cv.create_oval(115,36,160,74,fill=sp['color'],outline='#435149',width=2)
        if a.kind=='kiwi':
            cv.create_line(155,55,182,69,fill='#e5d0aa',width=4)
        elif a.kind in ('rat','stoat'):
            cv.create_line(118,63,90,78,fill=sp['color'],width=4)
        elif a.kind=='weta':
            for q in (111,122,138,153):cv.create_line(q,65,q-8,85,fill='#c4a685',width=2)
        elif a.kind=='human':
            cv.create_oval(125,26,148,50,fill='#e7bd96',outline='')
        cv.create_text(11,12,text=sp['tag'].upper(),anchor='nw',fill='#d4e9d6',font=('Segoe UI',8,'bold'))
        self.creature_info.set(f"{a.name}  •  ID {a.id}\n{sp['tag']} · {sp['role']}\nAge: {a.age:.1f} days  |  Energy: {a.energy:.0f}%\nThirst: {a.thirst*100:.0f}%  |  Health: {a.health:.0f}%\nEats: {sp['diet']}\nPredators / threats: {sp['predators']}")

    def toggle_pause(self):
        self.running=not self.running
        self.world.note('Time resumes.' if self.running else 'Time stands still.')

    def scatter_selected(self):
        choice=self.brush.get()
        if choice=='inspect':
            self.world.scatter('nutrients',50)
        elif choice in SPECIES:
            self.world.spawn(choice,{'kiwi':6,'weta':15,'rat':6,'stoat':3,'human':2}[choice])
        elif choice=='build':
            people=[a for a in self.world.creatures if a.kind=='human']
            if people:self.world.build_home(people[0].x,people[0].y)
        elif choice=='control':
            before=len(self.world.creatures)
            self.world.creatures=[a for a in self.world.creatures if a.kind not in ('rat','stoat')]
            self.world.note(f'Predator control removed {before-len(self.world.creatures)} introduced predators.')
        else:
            self.world.scatter(choice,140)

    def new_world(self):
        if messagebox.askyesno('New little world','Create a new ecosystem? Your current terrarium will be replaced.\n\nSave first if you want to keep it.'):
            self.world=World()
            self.inspect_pos=None
            self.selected_id=None
            self.refresh_controls()
            self.save_autosave()

    def save_autosave(self):
        try:
            HOME.mkdir(parents=True,exist_ok=True)
            temp=AUTOSAVE.with_suffix('.tmp')
            with temp.open('w',encoding='utf8') as f:json.dump(self.world.to_dict(),f)
            temp.replace(AUTOSAVE)
        except OSError as e:
            self.status.set(f'Autosave failed: {e}')

    def save_as(self):
        filename=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('Terrarium save','*.json')],
                                               initialfile='my_little_world.json')
        if filename:
            try:
                with open(filename,'w',encoding='utf8') as f:json.dump(self.world.to_dict(),f)
                self.world.note('World saved to a file.')
            except OSError as e:messagebox.showerror('Could not save',str(e))

    def load_file(self):
        filename=filedialog.askopenfilename(filetypes=[('Terrarium save','*.json')])
        if filename:
            try:
                with open(filename,encoding='utf8') as f:self.world=World.from_dict(json.load(f))
                self.inspect_pos=None
                self.selected_id=None
                self.refresh_controls()
                self.world.note('Welcome back to this little world.')
                self.save_autosave()
            except (OSError,ValueError,KeyError,TypeError) as e:messagebox.showerror('Could not load',str(e))

    def close(self):
        self.save_autosave()
        self.root.destroy()

    def draw(self):
        cv=self.canvas
        cv.delete('all')
        w=self.world
        daylight=w.sunlight
        night=clamp(1-daylight*.9)
        for y,row in enumerate(w.cells):
            for x,c in enumerate(row):
                if c['water']:
                    shimmer=.5+.5*math.sin(w.clock*.11+x*.76+y*.45)
                    color=hexrgb(21+shimmer*10+daylight*16,65+shimmer*12+daylight*22,84+shimmer*17+daylight*27)
                else:
                    green=c['plants']; moisture=c['moisture']; fungus=c['fungus']
                    dark=night*.34
                    color=hexrgb((51+green*12+fungus*8)*(1-dark),
                                 (55+green*75+moisture*8)*(1-dark),
                                 (40+green*31+moisture*11+fungus*14)*(1-dark))
                x0,y0=x*CELL,y*CELL
                cv.create_rectangle(x0,y0,x0+CELL+1,y0+CELL+1,fill=color,outline='')
                # vegetation silhouettes, flowers, fungus caps and scattered stones
                seed=((x*92837111)^(y*689287499)^w.seed)&0xffff
                ox=3+seed%9
                if not c['water']:
                    if c['plants']>.17:
                        tip=int(2+c['plants']*7)
                        green=hexrgb(70+daylight*33,125+c['plants']*65-night*37,75+daylight*16)
                        cv.create_line(x0+ox,y0+12,x0+ox-2,y0+12-tip,fill=green,width=1)
                        if c['plants']>.53:
                            cv.create_line(x0+ox+3,y0+13,x0+ox+5,y0+10-tip*.65,fill='#83b969' if night<.6 else '#578c61',width=1)
                    if c['flower'] and c['plants']>.33:
                        cv.create_oval(x0+ox-2,y0+4,x0+ox+2,y0+8,fill='#eacaad',outline='')
                    if c['fungus']>.22:
                        cap='#d5a489' if daylight>.25 else '#a07e78'
                        cv.create_line(x0+4,y0+11,x0+4,y0+8,fill='#c7b7a1',width=1)
                        cv.create_arc(x0+1,y0+5,x0+8,y0+10,start=0,extent=180,fill=cap,outline=cap)
                    if c['rock']:
                        cv.create_polygon(x0+2,y0+12,x0+4,y0+7,x0+9,y0+8,x0+12,y0+13,fill='#687674',outline='')
        # subtle weather overlay
        if w.raining:
            rr=random.Random(int(w.clock*15)+4)
            for _ in range(105):
                x=rr.randrange(W*CELL);y=rr.randrange(H*CELL)
                cv.create_line(x,y,x-3,y+9,fill='#79a6b3',width=1)
        if w.temperature<1:
            rr=random.Random(int(w.clock*2)+18)
            for _ in range(33):
                x=rr.randrange(W*CELL);y=rr.randrange(H*CELL)
                cv.create_oval(x,y,x+2,y+2,fill='#d1dfdb',outline='')
        # Human-built houses and villages occupy real habitat tiles.
        for settlement in w.settlements:
            px=settlement['x']*CELL;py=settlement['y']*CELL
            cv.create_rectangle(px+3,py+7,px+12,py+14,fill='#d5bc92',outline='#4c443b')
            cv.create_polygon(px+1,py+8,px+7,py+2,px+14,py+8,fill='#b96e59',outline='#6c433d')
            if settlement['kind']=='village':cv.create_text(px+8,py-3,text='⌂',fill='#f4e9c7',font=('Arial',9,'bold'))
        # Miniature sprite shapes: native animals and introduced species.
        for a in w.creatures:
            px=int(a.x*CELL)+CELL//2;py=int(a.y*CELL)+CELL//2
            c=SPECIES[a.kind]['color']
            if a.kind=='kiwi':
                cv.create_oval(px-5,py-4,px+5,py+4,fill=c,outline='#604737')
                cv.create_line(px+4,py,px+9,py+4,fill='#dbc89f',width=2)
                cv.create_line(px-1,py+3,px-2,py+6,fill='#b0a18d')
            elif a.kind=='weta':
                cv.create_oval(px-4,py-2,px+4,py+3,fill=c,outline='#41382e')
                for dx in (-3,0,3):cv.create_line(px+dx,py,px+dx+5,py+5,fill='#af9d87')
            elif a.kind=='stoat':
                cv.create_oval(px-5,py-3,px+5,py+3,fill=c,outline='#5a3d31')
                cv.create_line(px-4,py+1,px-9,py+4,fill='#373339',width=2)
            elif a.kind=='rat':
                cv.create_oval(px-4,py-3,px+4,py+3,fill=c,outline='#5e5053')
                cv.create_line(px-4,py,px-9,py+3,fill='#d0a5a9')
            elif a.kind=='human':
                cv.create_oval(px-3,py-7,px+3,py-1,fill='#e5b894',outline='')
                cv.create_rectangle(px-3,py,px+3,py+6,fill=c,outline='')
            if a.id==self.selected_id:
                cv.create_oval(px-10,py-11,px+10,py+11,outline='#fff2ae',width=2)
        if self.inspect_pos is not None:
            x,y=self.inspect_pos
            cv.create_rectangle(x*CELL,y*CELL,(x+1)*CELL,(y+1)*CELL,outline='#ffffff',width=2)
        # Day/night atmospheric veil at darkest hours
        if daylight<.18:
            for x,y,r in self.stars[:17]:
                if self.world.get(x/CELL,y/CELL)['water']:
                    cv.create_oval(x,y,x+r,y+r,fill='#d2e8c0',outline='')

    def update_ui(self):
        w=self.world
        counts,means=w.ecology_metrics()
        self.day_label.config(text=f'DAY {w.day:03}   ·   {w.season.upper()}')
        hr=int(w.hour);minute=int((w.hour-hr)*60)
        weather='☂ RAIN' if w.raining else ('☾ NIGHT' if w.sunlight<.08 else '☀ CLEAR')
        wet=sum(c['water'] for row in w.cells for c in row) / (W*H)*100
        self.weather_label.config(text=f'{hr:02}:{minute:02} · {w.temperature:.0f}°C · {weather} · WATER {wet:.0f}%')
        for label,kind in [('KIWI','kiwi'),('WĒTĀ','weta'),('RATS','rat'),('STOATS','stoat'),('HUMANS','human')]:
            self.stat_labels[label].config(text=str(counts[kind]))
        self.status.set(('● LIVE' if self.running else 'Ⅱ PAUSED')+f'  ·  {self.speed.get()}×')
        snapshot=tuple(w.events)
        if snapshot!=self.last_feed_snapshot:
            self.log.config(state='normal')
            self.log.delete('1.0','end')
            for day,msg in snapshot:
                self.log.insert('end',f'DAY {int(day)+1:03}  •  {msg}\n\n')
            self.log.config(state='disabled')
            self.last_feed_snapshot=snapshot
        self.update_inspector()
        self.update_creature_viewer()

    def loop(self):
        now=time.monotonic()
        elapsed=min(now-self.last_time,.4)
        self.last_time=now
        if self.running:
            self.accumulator+=elapsed*self.speed.get()*2.7
            iterations=0
            while self.accumulator>=1 and iterations<10:
                self.world.tick(.65)
                self.accumulator-=1
                iterations+=1
            if iterations>=10:
                self.accumulator=0
        self.tick_number+=1
        if self.tick_number%3==0:
            self.draw()
        if self.tick_number%8==0:
            self.update_ui()
        if now-self.last_autosave>60:
            self.save_autosave()
            self.last_autosave=now
        self.root.after(80,self.loop)


def main():
    root=tk.Tk()
    TerrariumApp(root)
    root.mainloop()


if __name__=='__main__':
    main()
