# LITTLE WORLDS — Aotearoa Terrarium (v0.3)

An experimental, New Zealand-inspired desktop ecosystem. Animals live, feed, hunt, reproduce, and die; fungi and microbes recycle organic material; rainfall expands the pond. People can build homes, alter habitats and carry out predator control. **The ecological model is simplified and not intended for scientific prediction.**

## Run on Windows

1. Install Python 3.10 or newer from https://www.python.org/downloads/ (with Tcl/Tk enabled).
2. Extract this ZIP.
3. Double-click **Launch Little Worlds.bat**. No third-party packages, account, internet or API keys required.

## What's new in v0.3

- **Creature viewer above the controls:** Select **Inspect**, then click a creature. Its portrait, name/ID, age, energy, thirst, health, feeding preferences, natural threats and ecological role appear in the fixed panel above the scrollable sliders.
- **New Zealand woodland-inspired food web:** Brown kiwi, forest wētā, introduced ship rats, introduced stoats and human settlers. Kiwi eat invertebrates; stoats hunt rats and vulnerable young kiwi; rats prey on wētā and sometimes kiwi young; wētā feed on plant and organic material. Food web is stylized.
- **Human-built structures:** Settlers periodically construct houses and villages on dry tiles, replacing vegetation. Building tools can place houses directly. Buildings are shown as small roof-and-wall icons.
- **Conservation intervention:** Predator-control brush removes introduced rats and stoats near a chosen tile. Settlement inhabitants may also perform occasional control operations.
- **Live feed:** Look beneath the habitat to read births, weather changes, deaths, construction, predation and predator-control outcomes.
- **Scrolling right controls:** Creature viewer remains at the top, above environmental sliders and tools.

## Controls

- **Inspect** → click a creature to select it (white circle highlights it) or empty ground to inspect a tile.
- **Kiwi / Wētā / Rats / Stoats / Humans** → click anywhere to introduce the selected organisms.
- **Build house** → click dry land to make a house or village. Humans also build periodically when present.
- **Predator control** → click to remove nearby introduced predators. The broad-action button removes introduced predators throughout the world.
- **Seeds / Fungi / Microbes / Minerals** → introduce ecological material.
- Change **Temperature**, **Rainfall**, **Sunlight** and **Metabolism**, or pause/speed up simulation.
- Save/load local JSON worlds, or let autosave preserve your work.

## Saves and migration

Autosaves are in `%USERPROFILE%\.little_worlds\autosave.json`. v0.3 reads v0.2 saves; existing fictional mossbacks, ember foxes and dusk beetles are mapped onto kiwi, stoats and wētā respectively. Opening an existing world continues its history but does not automatically spawn humans or rats; add these with the controls or create a new world to start with all species. **Make a backup of an old save before trying a new version** because the autosave upgrades to the new format after running.

## Limits

This is a deliberately stylized ecological toy, not a geographically specific or scientifically validated representation of Aotearoa. Species have schematic shapes, abbreviated diets and lifespan rules; climate seasons and reproduction are accelerated for playability. Houses mark settlement footprints but do not yet grow roads, farms or complex economies. Human actions are simplified to building, habitat change and predator control. Microbes are simulated as biomass per tile, not individual organisms.

## Optional Windows executable build

On a Windows computer with Python installed:

```
py -m pip install pyinstaller
py -m PyInstaller --noconfirm --onefile --windowed --name LittleWorlds terrarium.py
```

Find the resulting `dist\LittleWorlds.exe`. Windows executables should be compiled on Windows.
