# Little Worlds — v0.4: Aotearoa Living Terrarium

A little offline desktop ecosystem built with Python's standard-library Tkinter. An educational, *stylised* model rather than a validated ecology model.

## Launch on Windows

1. Extract the ZIP, keeping the `mini_ecosystem` folder and its contents together.
2. Install Python 3.10 or newer from python.org. Ensure Tcl/Tk is installed (default Windows installer includes it).
3. Double-click `Launch Little Worlds.bat`. Alternatively, open a terminal in this folder and run `python terrarium.py`.
4. If Windows reports it cannot find Python, reinstall it with the **Add python.exe to PATH** option, or launch using `py -3 terrarium.py`.

No additional Python packages or internet access are required. This is source-code software, **not an executable installer**.

## What is new in v0.4?

- **Individual lives:** animals inherit mildly variable speed, food efficiency, resilience and fertility; parents, generation number and traits are displayed when selected. Creatures tend to remain within a home range, flee predators, forage and reproduce. Population dynamics are intentionally simplified.
- **Disease:** rare random infections can spread among nearby members of the same species, reduce energy and health, and resolve with temporary immunity. Disease is an abstract mechanism, not a simulation of any specific real-world pathogen.
- **Human development modes:** Balanced, Expansion and Conservation control how rapidly people build and how often they control introduced predators. Settlements alter vegetation and occupy actual map tiles.
- **Ecological alerts:** the journal flags declining kiwi, high predator ratios, drought, vegetation loss, flooding, spread of settlements and outbreaks. Alerts include a brief ecological explanation and are rate-limited to avoid spam. They are toy-model heuristics, **not scientifically validated risk thresholds**.
- **Easier navigation:** the creature viewer remains at the top of the sidebar; the lower sidebar now has *Interventions* and *Ecology & guide* tabs. Warnings are colour-coded in the live feed.

## Controls

- **Inspect:** click near a creature to view its individual stats, food, predators, parents, genetics, and infection status. If no animal is nearby, click another occupied tile.
- **Speed:** pause or use 1×, 2×, 4× or 8×.
- **Interventions:** adjust temperature, rainfall, sunlight and metabolism; use species/soil tools by selecting one then clicking the map, or sprinkle across the habitat.
- **Development policy:** select Balanced, Conservation or Expansion to alter human behaviour. Changes apply immediately to future behaviour.
- **Save:** autosave approximately once a minute and on close; manually Save as… / Load… JSON files.
- **Ecology & guide:** a live summary of population, soil indicators and basic food-web lessons.

## Compatibility and save locations

The application can read v0.2 and v0.3 save-format versions. It preserves old creature data, assigning missing genetics lazily; previous saves should be backed up first. This version writes save format 3, which *older* releases may not read. Autosave resides at `%USERPROFILE%\.little_worlds\autosave.json` on Windows. To retain v0.3 separately, back up that file before opening v0.4.

## Educational caveats

The seasons are accelerated, animals and humans reproduce at invented game rates, predator interactions are abstractions, and settlements are abstract tiles. This is *not* a geographic model of NZ or a tool for forecasting species population viability. For actual NZ predator ecology, see:

- Department of Conservation: https://www.doc.govt.nz/nature/native-animals/birds/birds-a-z/kiwi/facts/
- Department of Conservation: https://www.doc.govt.nz/nature/pests-and-threats/animal-pests-and-threats/stoats/
- Department of Conservation: https://www.doc.govt.nz/predator-control-programme

## Ideas for future releases

More accurate vegetation strata, habitat fragmentation effects, specific diseases, litter/egg life cycles, realistic season and longevity scaling, long-running statistics charts and an editable intervention timeline.
