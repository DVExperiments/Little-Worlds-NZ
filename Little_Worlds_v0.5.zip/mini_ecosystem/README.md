# Little Worlds — v0.5: Aotearoa Living Terrarium

A little offline desktop ecosystem built with Python's standard-library Tkinter. An educational, *stylised* model rather than a validated ecology model.

## Launch on Windows

1. Extract the ZIP, keeping the `mini_ecosystem` folder and its contents together.
2. Install Python 3.10 or newer from python.org. Ensure Tcl/Tk is installed (default Windows installer includes it).
3. Double-click `Launch Little Worlds.bat`. Alternatively, open a terminal in this folder and run `python terrarium.py`.
4. If Windows reports it cannot find Python, reinstall it with the **Add python.exe to PATH** option, or launch using `py -3 terrarium.py`.

No additional Python packages or internet access are required. This is source-code software, **not an executable installer**.

## New in v0.5

- **History tab:** daily snapshots of kiwi, wētā, rat, stoat and human populations; plants, water coverage, soil moisture and nutrients; settlements, supplies and restoration plots. Switch graph categories using the dropdown. A major-event timeline provides context. Only newly observed days are tracked: earlier versions cannot reconstruct past graph values.
- **Resource-dependent settlements:** houses cost 7 shared supplies. People and buildings consume supplies, while local vegetation harvesting and abstracted off-map trade/cultivation replenish them. Expansion policy harvests more heavily. Scarcity triggers educational alerts.
- **Restoration:** choose **Restore habitat**, then click a dry, unbuilt tile. Each plot costs 4 restoration budget, visibly marks the map with a green square and gradually enriches plants and soil in its vicinity. Conservation policy can periodically start projects near villages. Budget replenishes over time; at a greater rate under Conservation policy.
- **More educational feedback:** the event feed and historical timeline record restoration work, supply shortages, construction, wildlife threats and environmental imbalances. The rules are illustrative rather than scientifically calibrated.
- **All v0.4 features retained:** creature portraits and details, inherited traits, disease, families, predator control and settlement-policy choices.

## Controls

- **Inspect:** click near a creature to view its individual stats, food, predators, parents, genetics, and infection status. If no animal is nearby, click another occupied tile.
- **Speed:** pause or use 1×, 2×, 4× or 8×.
- **Restoration:** choose Restore habitat in Interventions, then click a non-water tile; see the marked plot develop over subsequent days.
- **History:** select Populations, Habitat or Settlement to see daily trends and major events.
- **Interventions:** adjust temperature, rainfall, sunlight and metabolism; use species/soil tools by selecting one then clicking the map, or sprinkle across the habitat.
- **Development policy:** select Balanced, Conservation or Expansion to alter human behaviour. Changes apply immediately to future behaviour.
- **Save:** autosave approximately once a minute and on close; manually Save as… / Load… JSON files.
- **Ecology & guide:** a live summary of population, soil indicators and basic food-web lessons.

## Compatibility and save locations

The application can read v0.2, v0.3 and v0.4 save-format versions. It preserves old creature data, assigning missing genetics lazily; previous saves should be backed up first. This version writes save format 4, which *older* releases may not read. Autosave resides at `%USERPROFILE%\.little_worlds\autosave.json` on Windows. To retain your v0.4 world separately, back up that file before opening v0.5.

## Educational caveats

The seasons are accelerated, animals and humans reproduce at invented game rates, predator interactions are abstractions, and settlements are abstract tiles. This is *not* a geographic model of NZ or a tool for forecasting species population viability. For actual NZ predator ecology, see:

- Department of Conservation: https://www.doc.govt.nz/nature/native-animals/birds/birds-a-z/kiwi/facts/
- Department of Conservation: https://www.doc.govt.nz/nature/pests-and-threats/animal-pests-and-threats/stoats/
- Department of Conservation: https://www.doc.govt.nz/predator-control-programme

## Ideas for future releases

More accurate vegetation strata, habitat fragmentation effects, specific diseases, litter/egg life cycles, realistic season and longevity scaling, long-running statistics charts and an editable intervention timeline.
